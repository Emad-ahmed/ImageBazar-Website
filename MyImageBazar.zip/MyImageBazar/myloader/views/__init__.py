from myloader.views.home import HomeView, showcat, addphoto
from myloader.views.signup import SignView
from myloader.views.login import LoginView, user_logout
