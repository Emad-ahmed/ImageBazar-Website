from django.apps import AppConfig


class MyloaderConfig(AppConfig):
    name = 'myloader'
